#include <stdio.h>
#include <phase1.h>
#include <phase2.h>

#define CLOCK_BOX 0
#define DISK_BOX 1
#define TERM_BOX 3

extern int debugflag2;
extern void disableInterrupts(void);
extern void enableInterrupts(void);
extern void requireKernelMode(char *);

int IO_mail_boxes[7]; // mbox_ids for the IO devices
int IO_blocked = 0; // number of processes blocked on IO mailboxes


/* an error method to handle invalid syscalls */
void nullsys(sysargs *args)
{
    console("nullsys(): Invalid syscall %d. halting...\n", args->number);
    halt(1);
} /* nullsys */


void clock_handler(int dev, void *arg)
{
    disableInterrupts();
    requireKernelMode("clock_handler()");
    if (DEBUG2 && debugflag2)
      console("clock_handler(): called\n");

    // make sure this is the clock device, return otherwise
    if (dev != CLOCK_DEV) {
      if (DEBUG2 && debugflag2)
        console("clock_handler(): called by other device, returning\n");
      return;
    }

    // send message every 5 interrupts
    static int count = 0;
    count++;
    if (count == 5) {
      int status;
      device_input(dev, 0, &status); // get the status
      MboxCondSend(IO_mail_boxes[CLOCK_BOX], &status, sizeof(int));
      count = 0;
    }

    time_slice(); 
    enableInterrupts(); 
} /* clockHandler */


void disk_handler(int dev, void *arg)
{
    disableInterrupts();
    requireKernelMode("disk_handler()");
    if (DEBUG2 && debugflag2)
      console("disk_handler(): called\n");

    // make sure this is the disk device, return otherwise
    if (dev != DISK_DEV) {
      if (DEBUG2 && debugflag2)
        console("disk_handler(): called by other device, returning\n");
      return;
    }

    // get the device status
    long unit = (long)arg;
    int status;
    int valid = device_input(dev, unit, &status);

    // make sure the unit number was valid
    if (valid == DEV_INVALID) {
      if (DEBUG2 && debugflag2)
        console("disk_handler(): unit number invalid, returning\n");
      return;
    }

    // conditionally send to the device's mailbox
    MboxCondSend(IO_mail_boxes[DISK_BOX+unit], &status, sizeof(int));
    enableInterrupts(); // re-enable interrupts
} /* disk_handler */


void term_handler(int dev, void *arg)
{
    disableInterrupts();
    requireKernelMode("term_handler()");
    if (DEBUG2 && debugflag2)
      console("term_handler(): called\n");

    // make sure this is the terminal device, return otherwise
    if (dev != TERM_DEV) {
      if (DEBUG2 && debugflag2)
        console("term_handler(): called by other device, returning\n");
      return;
    }

    // get the device status
    long unit = (long)arg;
    int status;
    int valid = device_input(dev, unit, &status);

    // make sure the unit number was valid
    if (valid == DEV_INVALID) {
      if (DEBUG2 && debugflag2)
        console("term_handler(): unit number invalid, returning\n");
      return;
    }

    // conditionally send to the device's mailbox
    MboxCondSend(IO_mail_boxes[TERM_BOX+unit], &status, sizeof(int));
    enableInterrupts(); // re-enable interrupts
} /* term_handler */


void syscall_handler(int dev, void *arg)
{
  disableInterrupts();
  requireKernelMode("syscall_handler()");
  if (DEBUG2 && debugflag2)
      console("syscall_handler(): called\n");

  sysargs *sysPtr = (sysargs *) arg;

  // make sure this is the system call dveice, return otherwise
  if (dev != SYSCALL_INT) {
    if (DEBUG2 && debugflag2) 
      console("sysCallHandler(): called by other device, returning\n");
    return;
  }

  // check for correct system call number
  if (sysPtr->number < 0 || sysPtr->number >= MAXSYSCALLS) {
    console("syscall_handler(): sys number %d is wrong.  halting...\n", sysPtr->number);
    halt(1);
  }

  // call nullsys for now
  nullsys((sysargs*)arg);
  enableInterrupts();
} /* syscall_handler */


/* Returns 1 if there are processes blocked on IO, 0 otherwise */
int check_io() {
    return IO_blocked > 0 ? 1 : 0;
}


/* Does a receive operation on the mailbox associated with the given unit of the device type. */
int waitdevice(int type, int unit, int *status) 
{
    disableInterrupts();
    requireKernelMode("waitdevice()");

    int box;
    if (type == CLOCK_DEV)
      box = CLOCK_BOX;
    else if (type == DISK_DEV)
      box = DISK_BOX;
    else if (type == TERM_DEV)
      box = TERM_BOX;
    else {
      console("waitdevice(): Invalid device type; %d. halting...\n", type);
      halt(1);
    }

    IO_blocked++;
    MboxReceive(IO_mail_boxes[box+unit], status, sizeof(int));
    IO_blocked--;

    enableInterrupts(); // re-enable interrupts
    // return -1 if we were zapped while waiting, return 0 otherwise
    return is_zapped() ? -1 : 0; 
}