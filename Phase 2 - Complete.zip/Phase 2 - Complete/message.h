#define DEBUG2 1

typedef struct mailSlot *slot_ptr;
typedef struct mailbox   mailbox;
typedef struct mailSlot  mailSlot;
typedef struct mboxProc mboxProc;
typedef struct mboxProc *mboxProcPtr;
typedef struct queue queue;

struct mboxProc {
    mboxProcPtr     next_Mbox_Proc;
    int             pid;        // process ID
    void            *msg_ptr;   // pointer to received message
    int             msg_size;
    slot_ptr         messageReceived;    // Mail slot for recieved message
};

#define SLOTQUEUE 0
#define PROCQUEUE 1

struct queue {
    void   *head;
    void   *tail;
    int     size;
    int     type; 
};

struct mailbox {
    int       mbox_id;
    int       status;   // Status of mailbox
    int       total_slots;   // Number of total slots in mail box
    int       slot_size; 
    queue     slots; // queue of mail slots 
    queue     blocked_procs_send; // processes blocked on a MBoxSend
    queue     blocked_procs_receive; // processes blocked on a receive
};

struct mailSlot {
    int       mbox_id;
    int       status;
    int       slot_id;
    slot_ptr   nextslot_ptr;
    char      message[MAX_MESSAGE];
    int       messageSize;
};

// define mailbox status constants
#define INACTIVE 0
#define ACTIVE 1

// mail slot status constants
#define EMPTY 0
#define USED 1

// define process status constants
#define FULL_BOX 11
#define NO_MESSAGES 12

struct psrBits {
    unsigned int cur_mode:1;
    unsigned int cur_int_enable:1;
    unsigned int prev_mode:1;
    unsigned int prev_int_enable:1;
    unsigned int unused:28;
};

union psrValues {
    struct psrBits bits;
    unsigned int integer_part;
};