/* ------------------------------------------------------------------------
   phase2.c
   Applied Technology
   College of Applied Science and Technology
   The University of Arizona
   CSCV 452
   ------------------------------------------------------------------------ */

#include <phase1.h>
#include <phase2.h>
#include <usloss.h>
#include <stdlib.h>
#include <string.h>

#include "message.h"
#include "handler.c"

/* ------------------------- Prototypes ----------------------------------- */
int start1 (char *);
extern int start2 (char *);
void emptyBox(int);
void emptySlot(int);
void disableInterrupts(void);
void enableInterrupts(void);
void requireKernelMode(char *);
void initQueue(queue*, int);
void enq(queue*, void*);
void *deq(queue*);
void *peek(queue*);

/* -------------------------- Globals ------------------------------------- */

int debugflag2 = 0;

mailbox MailBoxTable[MAXMBOX]; // the mail boxes 
mailSlot MailSlotTable[MAXSLOTS]; // the mail slots
mboxProc mboxProcTable[MAXPROC];  // the processes

// the total number of mailboxes and mail slots in use
int numBoxes, numSlots;

// next mailbox/slot id to be assigned
int nextmbox_id = 0, nextslot_id = 0, nextProc = 0;

// system call vector
void (*syscall_vec[MAXSYSCALLS])(sysargs *args);

/* -------------------------- Functions ----------------------------------- */

/* ------------------------------------------------------------------------
   Name - start1
   Purpose - Initializes mailboxes and interrupt vector.
             Start the phase2 test process.
   Parameters - one, default arg passed by fork1, not used here.
   Returns - one to indicate normal quit.
   Side Effects - lots since it initializes the phase2 data structures.
   ----------------------------------------------------------------------- */
int start1(char *arg)
{
    if (DEBUG2 && debugflag2)
        console("start1(): at beginning\n");
    requireKernelMode("start1");

    // Disable interrupts
    disableInterrupts();

    // Initialize the mail box table, slots, & other data structures.
    // Initialize int_vec and system call handlers,
    // allocate mailboxes for interrupt handlers.  Etc... 

    // initialize mailbox table
    int i;
    for (i = 0; i < MAXMBOX; i++) {
        emptyBox(i);
    }

    // initialize mail slots
    for (i = 0; i < MAXSLOTS; i++) {
        emptySlot(i);
    }

    numBoxes = 0;
    numSlots = 0;

    // allocate mailboxes for interrupt handlers
    IO_mail_boxes[CLOCK_BOX] = MboxCreate(0, sizeof(int)); // one clock unit
    IO_mail_boxes[TERM_BOX] = MboxCreate(0, sizeof(int));  // 4 terminal units
    IO_mail_boxes[TERM_BOX+1] = MboxCreate(0, sizeof(int));
    IO_mail_boxes[TERM_BOX+2] = MboxCreate(0, sizeof(int));
    IO_mail_boxes[TERM_BOX+3] = MboxCreate(0, sizeof(int));
    IO_mail_boxes[DISK_BOX] = MboxCreate(0, sizeof(int));  // two disk units
    IO_mail_boxes[DISK_BOX+1] = MboxCreate(0, sizeof(int));

    // init interrupt handlers
    int_vec[CLOCK_INT] = clock_handler;
    int_vec[DISK_INT] = disk_handler;
    int_vec[TERM_INT] = term_handler;
    int_vec[SYSCALL_INT] = syscall_handler;

    // set all system calls to nullsys, fill next phase
    for (i = 0; i < MAXSYSCALLS; i++) {
        syscall_vec[i] = nullsys;
    }

    enableInterrupts();

    // Create a process for start2, then block on a join until start2 quits
    if (DEBUG2 && debugflag2)
        console("start1(): fork'ing start2 process\n");
    int kid_pid, status;
    kid_pid = fork1("start2", start2, NULL, 4 * USLOSS_MIN_STACK, 1);
    if ( join(&status) != kid_pid ) {
        console("start2(): join returned something other than ");
        console("start2's pid\n");
    }

    return 0;
} /* start1 */


/* ------------------------------------------------------------------------
   Name - requireKernelMode
   Purpose - Checks if we are in kernel mode and prints an error messages
              and halts USLOSS if not.
   Parameters - The name of the function calling it, for the error message.
   Side Effects - Prints and halts if we are not in kernel mode
   ------------------------------------------------------------------------ */
void requireKernelMode(char *name)
{
    if( (PSR_CURRENT_MODE & psr_get()) == 0 ) {
        console("%s: called while in user mode, by process %d. Halting...\n", 
             name, getpid());
        halt(1); 
    }
} /* requireKernelMode */


/*
 * Enables the interrupts.
 */
void enableInterrupts()
{
    // turn the interrupts ON iff we are in kernel mode
    if( (PSR_CURRENT_MODE & psr_get()) == 0 ) {
        //not in kernel mode
        console("Kernel Error: Not in kernel mode, may not ");
        console("enable interrupts\n");
        halt(1);
    } else
        // We ARE in kernel mode
        psr_set( psr_get() | PSR_CURRENT_INT );
} /* enableInterrupts */


/*
 * Disables the interrupts.
 */
void disableInterrupts()
{
    // turn the interrupts OFF iff we are in kernel mode
    if( (PSR_CURRENT_MODE & psr_get()) == 0 ) {
        //not in kernel mode
        console("Kernel Error: Not in kernel mode, may not ");
        console("disable interrupts\n");
        halt(1);
    } else
        // We ARE in kernel mode
        psr_set( psr_get() & ~PSR_CURRENT_INT );
} /* disableInterrupts */


/* ------------------------------------------------------------------------
   Name - MboxCreate
   Purpose - gets a free mailbox from the table of mailboxes and initializes it 
   Parameters - maximum number of slots in the mailbox and the max size of a msg
                sent to the mailbox.
   Returns - -1 to indicate that no mailbox was created, or a value >= 0 as the
             mailbox id.
   Side Effects - initializes one element of the mail box array. 
   ----------------------------------------------------------------------- */
int MboxCreate(int slots, int slot_size)
{
    // disable interrupts and require kernel mode
    disableInterrupts();
    requireKernelMode("MboxCreate()");

    // check if all mailboxes are used, and for illegal arguments
    if (numBoxes == MAXMBOX || slots < 0 || slot_size < 0 || slot_size > MAX_MESSAGE) {
            if (DEBUG2 && debugflag2) 
                console("MboxCreate(): illegal args or max boxes reached, returning -1\n");
        return -1;
    }

    // if the index is taken, find the first avaliable index
    if (nextmbox_id >= MAXMBOX || MailBoxTable[nextmbox_id].status == ACTIVE) {
        for (int i = 0; i < MAXMBOX; i++) {
            if (MailBoxTable[i].status == INACTIVE) {
                nextmbox_id = i;
                break;
            }
        }
    }

    // get mailbox
    mailbox *box = &MailBoxTable[nextmbox_id];

    // initialize fields
    box->mbox_id = nextmbox_id++;
    box->total_slots = slots;
    box->slot_size = slot_size;
    box->status = ACTIVE;
    initQueue(&box->slots, SLOTQUEUE);
    initQueue(&box->blocked_procs_send, PROCQUEUE);
    initQueue(&box->blocked_procs_receive, PROCQUEUE);

    numBoxes++; // increment mailbox count

    if (DEBUG2 && debugflag2) {
        console("MboxCreate(): created mailbox with id = %d, total_slots = %d, slot_size = %d, numBoxes = %d\n", box->mbox_id, box->total_slots, box->slot_size, numBoxes);
    }

    enableInterrupts(); // re-enable interrupts
    return box->mbox_id;
} /* MboxCreate */


/* ------------------------------------------------------------------------
   Name - send
   Purpose - Put a message into a slot for the indicated mailbox.
   Parameters - mailbox id, pointer to data of msg, # of bytes in msg, 
                type of send ( 0 for regular, 1 for conditional)
   Returns - zero if successful, -1 if invalid args, -2 if not sent.
   Side Effects - none.
   ----------------------------------------------------------------------- */
int send(int mbox_id, void *msg_ptr, int msg_size, int conditional)
{
    // disable interrupts and require kernel mode
    disableInterrupts();
    requireKernelMode("MboxSend()");
    if (DEBUG2 && debugflag2) 
        console("send(): called with mbox_id: %d, msg_ptr: %d, msg_size: %d, conditional: %d\n", mbox_id, msg_ptr, msg_size, conditional);

    // invalid mbox_id
    if (mbox_id < 0 || mbox_id >= MAXMBOX) {
        if (DEBUG2 && debugflag2) 
            console("Send(): called with invalid mbox_id: %d, returning -1\n", mbox_id);
        enableInterrupts(); // re-enable interrupts
        return -1;
    }

    // get the mailbox
    mailbox *box = &MailBoxTable[mbox_id];

    // check for invalid arguments
    if (box->status == INACTIVE || msg_size < 0 || msg_size > box->slot_size) {
        if (DEBUG2 && debugflag2) 
            console("MboxSend(): called with and invalid argument, returning -1\n", mbox_id);
        enableInterrupts(); // re-enable interrupts
        return -1;
    }

    // handle blocked receiver
    if (box->blocked_procs_receive.size > 0 && (box->slots.size < box->total_slots || box->total_slots == 0)) {
        mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_receive);
        // give the message to the receiver
        int result = sendToProc(proc, msg_ptr, msg_size);
        if (DEBUG2 && debugflag2) 
            console("MboxSend(): unblocking process %d that was blocked on receive\n", proc->pid);
        unblock_proc(proc->pid);
        enableInterrupts(); // re-enable interrupts
        if (result < 0) 
            return -1;
        return 0;
    }

    // if all the slots are taken, block caller until slots are avaliable
    if (box->slots.size == box->total_slots) {
        // don't block on a conditional send, return -2 instead
        if (conditional) {
            if (DEBUG2 && debugflag2) 
                console("MboxSend(): conditional send failed, returning -2\n");
            enableInterrupts(); // re-enable interrupts
            return -2;
        }

        // init proc details
        mboxProc mproc;
        mproc.next_Mbox_Proc = NULL;
        mproc.pid = getpid();
        mproc.msg_ptr = msg_ptr;
        mproc.msg_size = msg_size;

        if (DEBUG2 && debugflag2) 
            console("MboxSend(): all slots are full, blocking pid %d...\n", mproc.pid);

        // add to queue of send blocked processes at this mailbox
        enq(&box->blocked_procs_send, &mproc);

        block_me(FULL_BOX); // block
        disableInterrupts(); // disable interrupts again when it gets unblocked

        // return -3 if process zap'd or the mailbox released while blocked on the mailbox
        if (is_zapped() || box->status == INACTIVE) {
            if (DEBUG2 && debugflag2) 
                console("MboxSend(): process %d was zapped while blocked on a send, returning -3\n", mproc.pid);
            enableInterrupts(); // enable interrupts before return
            return -3;
        }
        enableInterrupts(); // enable interrupts before return
        return 0;
    }

    // if the mail slot table overflows, that is an error that should halt USLOSS
    if (numSlots == MAXSLOTS) {
        if (conditional) {
            if (DEBUG2 && debugflag2) 
                console("No slots avaliable for conditional send to box %d, returning -2\n", mbox_id);
            return -2;
        }
        console("Mail slot table overflow. Halting...\n");
        halt(1);
    }

    // create a new slot and add the message to it
    int slot_id = createSlot(msg_ptr, msg_size);
    slot_ptr slot = &MailSlotTable[slot_id];
    enq(&box->slots, slot); // add slot to mailbox

    enableInterrupts(); // enable interrupts before return
    return 0;
} /* send */


/* ------------------------------------------------------------------------
   Name - MboxSend
   Purpose - Put a message into a slot for the indicated mailbox.
             Block the sending process if no slot available.
   Parameters - mailbox id, pointer to data of msg, # of bytes in msg.
   Returns - zero if successful, -1 if invalid args.
   Side Effects - none.
   ----------------------------------------------------------------------- */
int MboxSend(int mbox_id, void *msg_ptr, int msg_size)
{
    return send(mbox_id, msg_ptr, msg_size, 0);
} /* MboxSend */


/* ------------------------------------------------------------------------
   Name - MboxReceive
   Purpose - Get a msg from a slot of the indicated mailbox.
             Block the receiving process if no msg available.
   Parameters - mailbox id, pointer to put data of msg, max # of bytes that
                can be received.
   Returns - actual size of msg if successful, -1 if invalid args.
   Side Effects - none.
   ----------------------------------------------------------------------- */
int MboxReceive(int mbox_id, void *msg_ptr, int msg_size)
{
    return receive(mbox_id, msg_ptr, msg_size, 0);
} /* MboxReceive */


/* ------------------------------------------------------------------------
   Name - MboxRelease
   Purpose - releases a mailbox
   Parameters - ID of the mailbox to release
   Returns - -3 if caller was zap'd, -1 if mail_box_id is invalid, 0 otherwise.
   Side Effects - zaps any processes blocked on the mailbox
   ----------------------------------------------------------------------- */
int MboxRelease(int mail_box_id) {
    // disable interrupts and require kernel mode
    disableInterrupts();
    requireKernelMode("MboxRelease()");

    // check if mail_box_id is invalid
    if (mail_box_id < 0 || mail_box_id >= MAXMBOX) {
        if (DEBUG2 && debugflag2) 
            console("MboxRelease(): called with invalid mail_box_id: %d, returning -1\n", mail_box_id);
        return -1;
    }

    // get mailbox
    mailbox *box = &MailBoxTable[mail_box_id];

    // check if mailbox is in use
    if (box == NULL || box->status == INACTIVE) {
        if (DEBUG2 && debugflag2) 
            console("MboxRelease(): mailbox %d is already released, returning -1\n", mail_box_id);
        return -1;
    }

    // empty the slots in the mailbox
    while (box->slots.size > 0) {
        slot_ptr slot = (slot_ptr)deq(&box->slots);
        emptySlot(slot->slot_id);
    }

    // release the mailbox
    emptyBox(mail_box_id);

    if (DEBUG2 && debugflag2) 
        console("MboxRelease(): released mailbox %d\n", mail_box_id);

    // unblock any processes blocked on a send 
    while (box->blocked_procs_send.size > 0) {
        mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_send);
        unblock_proc(proc->pid);
        disableInterrupts(); // re-disable interrupts
    }

    // unblock any processes blocked on a receive 
    while (box->blocked_procs_receive.size > 0) {
        mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_receive);
        unblock_proc(proc->pid);
        disableInterrupts(); // re-disable interrupts
    }

    enableInterrupts(); // enable interrupts before return
    return 0;
}


/* ------------------------------------------------------------------------
   Name - createSlot
   Purpose - gets a free slot from the table of mail slots and initializes it 
   Parameters - pointer to the message to put in the slot, and the message size.
   Returns - ID of the new slot.
   Side Effects - initializes one element of the mail slot array. 
   ----------------------------------------------------------------------- */
int createSlot(void *msg_ptr, int msg_size)
{
    // disable interrupts and require kernel mode
    disableInterrupts();
    requireKernelMode("createSlot()");

    // if the index is taken, find the first avaliable index
    if (nextslot_id >= MAXSLOTS || MailSlotTable[nextslot_id].status == USED) {
        for (int i = 0; i < MAXSLOTS; i++) {
            if (MailSlotTable[i].status == EMPTY) {
                nextslot_id = i;
                break;
            }
        }
    }

    // assumes parameters were already checked to be valid by caller
    slot_ptr slot = &MailSlotTable[nextslot_id];
    slot->slot_id = nextslot_id++;
    slot->status = USED;
    slot->messageSize = msg_size;
    numSlots++;

    // copy the message into the slot
    memcpy(slot->message, msg_ptr, msg_size);

    if (DEBUG2 && debugflag2) 
        console("createSlot(): created new slot for message size %d, slot_id: %d, total slots: %d\n", msg_size, slot->slot_id, numSlots);

    return slot->slot_id;
} /* createSlot */


/* ------------------------------------------------------------------------
   Name - sendToProc
   Purpose - sends a message directly to a process
   Parameters - pointer to the process, message to put in the slot, 
                and the message size.
   Returns - 0 for success or -1 for failure
   Side Effects - none? 
   ----------------------------------------------------------------------- */
int sendToProc(mboxProcPtr proc, void *msg_ptr, int msg_size)
{
    // check for error cases and return -1
    if (proc == NULL || proc->msg_ptr == NULL || proc->msg_size < msg_size) {
        if (DEBUG2 && debugflag2) 
            console("sendToProc(): invalid args, returning -1\n");
        proc->msg_size = -1;
        return -1;
    }

    // copy the message
    memcpy(proc->msg_ptr, msg_ptr, msg_size);
    proc->msg_size = msg_size;

    if (DEBUG2 && debugflag2) 
        console("sendToProc(): gave message size %d to process %d\n", msg_size, proc->pid);

    return 0;
}



/* ------------------------------------------------------------------------
   Name - MboxCondSend
   Purpose - Put a message into a slot for the indicated mailbox.
   Parameters - mailbox id, pointer to data of msg, # of bytes in msg.
   Returns - zero if successful, -1 if invalid args, -2 if message not sent
   Side Effects - none.
   ----------------------------------------------------------------------- */
int MboxCondSend(int mbox_id, void *msg_ptr, int msg_size)
{
    return send(mbox_id, msg_ptr, msg_size, 1);
} /* MboxCondSend */


/* ------------------------------------------------------------------------
   Name - receive
   Purpose - Get a msg from a slot of the indicated mailbox.
   Parameters - mailbox id, pointer to put data of msg, max # of bytes that
                can be received, type of receive (0 for regular, 1 for conditional)
   Returns - actual size of msg if successful, -1 if invalid args, 
                -2 if conditional receive failed.
   Side Effects - none.
   ----------------------------------------------------------------------- */
int receive(int mbox_id, void *msg_ptr, int msg_size, int conditional)
{
    // disable interrupts and require kernel mode
    disableInterrupts();
    requireKernelMode("MboxReceive()");
    slot_ptr slot;

    // invalid mbox_id
    if (mbox_id < 0 || mbox_id >= MAXMBOX) {
        if (DEBUG2 && debugflag2) 
            console("MboxReceive(): called with invalid mbox_id: %d, returning -1\n", mbox_id);
        enableInterrupts(); // re-enable interrupts
        return -1;
    }

    mailbox *box = &MailBoxTable[mbox_id];
    int size;

    // make sure box is valid
    if (box->status == INACTIVE) {
        if (DEBUG2 && debugflag2) 
            console("MboxReceive(): invalid box id: %d, returning -1\n", mbox_id);
        enableInterrupts(); // re-enable interrupts
        return -1;
    }

    // handle 0 slot mailbox
    if (box->total_slots == 0) {
        mboxProc mproc;
        mproc.next_Mbox_Proc = NULL;
        mproc.pid = getpid();
        mproc.msg_ptr = msg_ptr;
        mproc.msg_size = msg_size;

        // if a process has sent, unblock it and get the message
        if (box->blocked_procs_send.size > 0) {
            mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_send);
            sendToProc(&mproc, proc->msg_ptr, proc->msg_size);
            if (DEBUG2 && debugflag2) 
                console("MboxReceive(): unblocking process %d that was blocked on send to 0 slot mailbox\n", proc->pid);
            unblock_proc(proc->pid);
        }
        // otherwise block the receiver (if not conditional)
        else if (!conditional) {
            if (DEBUG2 && debugflag2) 
                console("MboxReceive(): blocking process %d on 0 slot mailbox\n", mproc.pid);
            enq(&box->blocked_procs_receive, &mproc);
            block_me(NO_MESSAGES);

            if (is_zapped() || box->status == INACTIVE) {
                if (DEBUG2 && debugflag2) 
                    console("MboxSend(): process %d was zapped while blocked on a send, returning -3\n", mproc.pid);
                enableInterrupts(); // enable interrupts before return
                return -3;
            }     
        }

        enableInterrupts(); // re-enable interrupts
        return mproc.msg_size;
    }

    // block if there are no messages avaliable 
    if (box->slots.size == 0) {
        // init proc details
        mboxProc mproc;
        mproc.next_Mbox_Proc = NULL;
        mproc.pid = getpid();
        mproc.msg_ptr = msg_ptr;
        mproc.msg_size = msg_size;
        mproc.messageReceived = NULL;

        // handle 0 slot mailbox, if a process has sent, unblock it and get the message
        if (box->total_slots == 0 && box->blocked_procs_send.size > 0) {
            mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_send);
            sendToProc(&mproc, proc->msg_ptr, proc->msg_size);
            if (DEBUG2 && debugflag2) 
                console("MboxReceive(): unblocking process %d that was blocked on send to 0 slot mailbox\n", proc->pid);
            unblock_proc(proc->pid);
            enableInterrupts(); // re-enable interrupts
            return mproc.msg_size;
        }

        // don't block on a conditional receive, return -2 instead
        if (conditional) {
            if (DEBUG2 && debugflag2) 
                console("MboxReceive(): conditional receive failed, returning -2\n");
            enableInterrupts(); // re-enable interrupts
            return -2;
        }

        if (DEBUG2 && debugflag2) 
            console("MboxReceive(): no messages avaliable, blocking pid %d...\n", mproc.pid);

        // add to queue of blocked procs on a receive
        enq(&box->blocked_procs_receive, &mproc);
        block_me(NO_MESSAGES); // block
        disableInterrupts(); // disable interrupts again when it gets unblocked

        // return -3 if process zap'd or the mailbox released while blocked on the mailbox
        if (is_zapped() || box->status == INACTIVE) {
            if (DEBUG2 && debugflag2) 
                console("MboxReceive(): either process %d was zapped, mailbox was freed, or we did not get the message, returning -3\n", mproc.pid);
            enableInterrupts(); // enable interrupts before return
            return -3;
        }

        return mproc.msg_size;
    }

    else
        slot = deq(&box->slots); // get the mailSlot

    // check if they don't have enough room for the message
    if (slot == NULL || slot->status == EMPTY || msg_size < slot->messageSize) {
        if (DEBUG2 && debugflag2 && (slot == NULL || slot->status == EMPTY)) 
                console("MboxReceive(): mail slot null or empty, returning -1\n");
        else if (DEBUG2 && debugflag2) 
            console("MboxReceive(): no room for message, room provided: %d, message size: %d, returning -1\n", msg_size, slot->messageSize);
        enableInterrupts(); // re-enable interrupts
        return -1;
    }

    // finally, copy the message
    size = slot->messageSize;
    memcpy(msg_ptr, slot->message, size);

    // free the mail slot
    emptySlot(slot->slot_id);

    // unblock a proc that is blocked on a send to this mailbox
    if (box->blocked_procs_send.size > 0) {
        mboxProcPtr proc = (mboxProcPtr)deq(&box->blocked_procs_send);
        // create slot for the sender's message
        int slot_id = createSlot(proc->msg_ptr, proc->msg_size);
        slot_ptr slot = &MailSlotTable[slot_id];
        enq(&box->slots, slot); // add the slot
        // unblock the sender
        if (DEBUG2 && debugflag2) 
            console("MboxReceive(): unblocking process %d that was blocked on send\n", proc->pid);
        unblock_proc(proc->pid);
    }

    enableInterrupts(); // enable interrupts before return
    return size;
} /* receive */


/* ------------------------------------------------------------------------
   Name - MboxCondReceive
   Purpose - Get a msg from a slot of the indicated mailbox.
   Parameters - mailbox id, pointer to put data of msg, max # of bytes that
                can be received.
   Returns - actual size of msg if successful, -1 if invalid args,
                -2 if receive failed.
   Side Effects - none.
   ----------------------------------------------------------------------- */
int MboxCondReceive(int mbox_id, void *msg_ptr, int msg_size)
{
    return receive(mbox_id, msg_ptr, msg_size, 1);
} /* MboxCondReceive */


/* ------------------------------------------------------------------------
   Name - emptyBox
   Purpose - Initializes a mailbox.
   Parameters - index of the mailbox in the mailbox table.
   Returns - nothing.
   Side Effects - none.
   ----------------------------------------------------------------------- */
void emptyBox(int i)
{
    MailBoxTable[i].mbox_id = -1;
    MailBoxTable[i].status = INACTIVE;
    MailBoxTable[i].total_slots = -1;
    MailBoxTable[i].slot_size = -1;
    numBoxes--; 
} /* emptyBox */


/* ------------------------------------------------------------------------
   Name - emptySlot
   Purpose - Initializes a mail slot.
   Parameters - index of the mail slot in the mail slot table.
   Returns - nothing.
   Side Effects - none.
   ----------------------------------------------------------------------- */
void emptySlot(int i)
{
    MailSlotTable[i].mbox_id = -1;
    MailSlotTable[i].status = EMPTY;
    MailSlotTable[i].slot_id = -1;
    numSlots--;
} /* emptySlot */


/* ------------------------------------------------------------------------
  Functions for queue:
    initQueue, enq, deq, and peek.
   ----------------------------------------------------------------------- */

/* Initialize the given queue */
void initQueue(queue* q, int type) {
    q->head = NULL;
    q->tail = NULL;
    q->size = 0;
    q->type = type;
}

/* Add the given pointer to the back of the given queue. */
void enq(queue* q, void* p) {
    if (q->head == NULL && q->tail == NULL) {
        q->head = q->tail = p;
    } else {
        if (q->type == SLOTQUEUE)
            ((slot_ptr)(q->tail))->nextslot_ptr = p;
        else if (q->type == PROCQUEUE)
            ((mboxProcPtr)(q->tail))->next_Mbox_Proc = p;
        q->tail = p;
    }
    q->size++;
}

/* Remove and return the head of the given queue. */
void* deq(queue* q) {
    void* temp = q->head;
    if (q->head == NULL) {
        return NULL;
    }
    if (q->head == q->tail) {
        q->head = q->tail = NULL; 
    }
    else {
        if (q->type == SLOTQUEUE)
            q->head = ((slot_ptr)(q->head))->nextslot_ptr;  
        else if (q->type == PROCQUEUE)
            q->head = ((mboxProcPtr)(q->head))->next_Mbox_Proc;  
    }
    q->size--;
    return temp;
}

/* Return the head of the given queue. */
void* peek(queue* q) {
    return q->head;   
}